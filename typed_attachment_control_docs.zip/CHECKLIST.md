
# CHECKLIST.md

## Invariants

- Graph/topology remains source of truth
- Builder owns semantics
- Optimizer consumes compiled semantics
- Framework remains role-agnostic

## Compatibility

- Flat X-anchor arrays remain unchanged
- Legacy optimizer path must continue to work

## Scope Control

- No redesign of builder or optimizer
- No schema changes to graph structures
- No removal of existing functions

## Self Review

- Slot metadata preserved through pipeline
- No phase leakage
- All new structures documented
