
# PLAN.md

Branch: typed-attachment-slots

Planner role: planning only
Executor role: implementation only

Objective:
Preserve typed attachment-slot identity (e.g. XA, XA, Al, Al) across the
builder → optimizer → placement pipeline while maintaining full backward
compatibility with the legacy flat X-anchor optimizer interface.

The topology graph remains the source of truth.
Builder compiles semantics.
Optimizer consumes compiled semantics.
Framework remains role-agnostic.

No redesign of the pipeline is permitted.
This branch strictly adds typed-slot preservation and resolution.

---

# Phase Roadmap

## Phase 1 — Typed Attachment Position Extraction

Goal
Expose attachment positions together with slot metadata while preserving
existing flat X-anchor structures.

Actions
- Introduce typed attachment extraction helper
- Extract slot_type and slot_ordinal metadata
- Align metadata rows with flattened attachment ordering
- Preserve existing `x_coords` arrays unchanged

Outputs
- typed_attachment_position_dict
- typed_attachment_metadata

Scope
Extraction only. No placement or optimizer changes.

---

## Phase 2 — Typed Attachment Lookup Construction

Goal
Construct lookup tables mapping `(slot_type, ordinal)` to attachment positions.

Actions
- Build lookup tables for node attachments
- Build lookup tables for edge attachments
- Guarantee deterministic lookup ordering

Outputs
- node_attachment_lookup
- edge_attachment_lookup

Scope
Lookup structures only. No optimizer changes.

---

## Phase 3 — Semantic Placement Integration

Goal
Resolve anchors using slot identity instead of flattened ordering.

Actions
- Modify anchor resolution helpers
- Prefer typed lookup when metadata exists
- Maintain fallback to flat anchor list

Outputs
- deterministic anchor resolution

Scope
Placement layer only.

---

## Phase 4 — Optimizer Seed Alignment

Goal
Allow rotation initialization to optionally use semantic slot ordering.

Actions
- Add optional typed anchor ordering during rotation seed generation
- Preserve legacy flat ordering for compatibility

Outputs
- improved optimizer stability for heterogeneous anchors

Scope
Seed initialization only. No change to optimizer algorithm.

---

## Phase 5 — Validation and Regression Tests

Goal
Ensure correctness and backward compatibility.

Actions
- Add heterogeneous anchor node tests
- Validate XA/XA/Al/Al preservation
- Confirm legacy behavior unchanged

Outputs
- regression coverage
