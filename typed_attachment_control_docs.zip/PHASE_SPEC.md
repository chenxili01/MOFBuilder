
# PHASE_SPEC.md

Executor must implement **one phase at a time**.
No cross-phase changes allowed.

---

## Phase 1 — Typed Attachment Position Extraction

Allowed Modules
- optimizer.py
- node.py
- linker.py

Required Work
- Implement typed attachment extraction helper
- Preserve `(slot_type, ordinal)` metadata
- Ensure alignment with flat anchor ordering

Forbidden Changes
- Optimizer algorithm changes
- Placement logic changes
- Graph structure changes

Completion Criteria
- Metadata correctly maps to flattened anchor indices
- Existing builds run unchanged

---

## Phase 2 — Typed Attachment Lookup Construction

Allowed Modules
- optimizer.py
- builder.py

Required Work
- Build lookup dictionary keyed by `(slot_type, ordinal)`
- Validate deterministic ordering

Forbidden Changes
- Placement logic
- Optimizer behavior

Completion Criteria
- Lookup resolves anchors correctly

---

## Phase 3 — Semantic Placement Integration

Allowed Modules
- builder.py
- linker.py

Required Work
- Update anchor resolution helpers
- Prefer semantic lookup when available

Forbidden Changes
- Optimizer algorithm
- Graph schema

Completion Criteria
- XA/XA/Al/Al nodes resolve anchors correctly

---

## Phase 4 — Optimizer Seed Alignment

Allowed Modules
- optimizer.py

Required Work
- Support typed slot ordering in rotation seed stage
- Maintain fallback to flat ordering

Forbidden Changes
- Optimizer cost function
- Rotation algorithm

Completion Criteria
- Optimizer produces same results for legacy nodes

---

## Phase 5 — Validation and Regression Tests

Allowed Modules
- tests/

Required Work
- Add heterogeneous anchor tests
- Confirm backward compatibility

Forbidden Changes
- Core logic changes

Completion Criteria
- All tests pass
